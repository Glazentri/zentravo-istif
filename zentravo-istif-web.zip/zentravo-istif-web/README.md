# Zentravo by Glazentri — web load planner

This is the scoped browser adaptation of İstif used by WinMatch for construction and glazing logistics. It includes the local packing worker, three-dimensional scene, cargo/vehicle catalogue, route estimator, label generation, source modules, upstream provenance and test cases. The desktop application is maintained separately in the original fork.

## Run locally

The bundled browser build is included. From this folder run `python3 -m http.server 8080 --directory public`, then open `http://localhost:8080/container-studio/`. No backend or API credentials are required for the standalone planner.

To rebuild from source: `npm install`, then `npm run build`. Run `npm test` for the engine and integration regression tests.

## Scope and integration

The standalone planner uses browser storage. The source includes the same-origin WinMatch integration message interface, but WinMatch cloud persistence, IFC export and other parent-workspace functionality require the actual WinMatch host and are not part of this standalone package. The platform database, user records, project data and private services are not included. The standalone page deliberately omits the shipping-board link.

See GLAZENTRI_CHANGES.md for the change history. Upstream İstif copyright © 2026 Cuma Ali Dirik, MIT licence retained in LICENSE-ISTIF.txt and vendor/istif/LICENSE. Three.js and the included fonts retain their own notices. Glazentri/Zentravo marks identify the adaptation and are not part of the upstream project.

Planning only: confirm the actual vehicle, gross masses, cargo restraint, handling and legal limits with the carrier.
