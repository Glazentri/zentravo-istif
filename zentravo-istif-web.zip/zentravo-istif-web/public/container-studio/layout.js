/* Device-local workspace visibility. Cargo and project exports remain independent. */
(function(){
 const key='zentravo-planner-layout-v1';
 const panels=[
  ['header','.app-header','Application header'],['reference','.title-line','Shipment reference'],
  ['stats','#kpis','Top statistics'],['equipment','.setup','Vehicle & cargo menu'],
  ['library','.cargo-library-section','Cargo library'],['inspector','.inspector','Selected cargo'],
  ['staging','.staging-panel','Unplaced cargo'],['tools','.stage-tools','Canvas toolbar'],
  ['hint','.canvas-hint','Mouse & keyboard help'],['animation','.sequence-controls','Loading playback'],
  ['legend','#legend','Cargo colour legend'],['packing','#td-packing-card','Delivery packing register'],['route','#td-route','Delivery route & fuel'],['truck','#td-vehicle-card','Truck dimensions & sites'],['costs','#td-cost-card','Labour & machinery rates']
 ];
 let prefs={};try{prefs=JSON.parse(localStorage.getItem(key)||'{}');}catch{}
 const library=document.getElementById('cargo-library'),heading=library.previousElementSibling;
 const group=document.createElement('section');group.className='cargo-library-section';heading.before(group);group.append(heading,library);
 const menu=document.createElement('details');menu.className='layout-menu';
 menu.innerHTML='<summary>Show / hide panels</summary><div class="layout-menu-body"><strong>Workspace layout</strong><p>Minimise keeps a title strip. Hide removes it.</p>'+panels.map(([id,,label])=>'<label>'+label+'<select data-layout="'+id+'" aria-label="'+label+' visibility"><option value="open">Show</option><option value="min">Minimise</option><option value="hide">Hide</option></select></label>').join('')+'<button type="button" id="layout-reset">Restore default layout</button></div>';
 document.querySelector('.workspace-tabs').append(menu);
 const restore=document.createElement('button');restore.type='button';restore.className='restore-panels';restore.textContent='Restore panels';restore.title='Show every hidden or minimised panel';restore.onclick=()=>{prefs={};try{localStorage.removeItem(key);}catch{}apply();};menu.before(restore);
 const hiddenPanels=document.createElement('div');hiddenPanels.className='hidden-panels';hiddenPanels.setAttribute('aria-label','Hidden panel restore controls');document.getElementById('workspace-panel').before(hiddenPanels);
 const icons={min:'−',hide:'×',open:'+'};
 function decorate(){for(const [id,selector,label] of panels){
  const el=document.querySelector(selector);if(!el)continue;
  if(['equipment','library','inspector','staging','packing','route','truck','costs'].includes(id)&&!el.querySelector('.panel-visibility')){
   let head=el.querySelector('.panel-heading');if(!head){const title=el.querySelector('h3');if(!title)continue;head=document.createElement('div');head.className='td-panel-head';title.before(head);head.append(title);}
   const controls=document.createElement('div');controls.className='panel-visibility';
   for(const action of ['min','hide']){const b=document.createElement('button');b.type='button';b.textContent=icons[action];b.dataset.panelAction=action;b.title=(action==='min'?'Minimise':'Hide')+' '+label;b.setAttribute('aria-label',b.title);b.onclick=()=>set(id,action==='min'&&prefs[id]==='min'?'open':action);controls.append(b);}
   head.append(controls);
  }
 }
 }
 function set(id,value){prefs[id]=value;try{localStorage.setItem(key,JSON.stringify(prefs));}catch{}apply();}
 function apply(){
  decorate();
  for(const [id,selector,label] of panels){const el=document.querySelector(selector);if(!el)continue;const value=['min','hide'].includes(prefs[id])?prefs[id]:'open';
   el.hidden=value==='hide';el.classList.toggle('layout-minimised',value==='min');document.body.dataset['layout'+id[0].toUpperCase()+id.slice(1)]=value;
   menu.querySelector('[data-layout="'+id+'"]').value=value;
   const b=el.querySelector('[data-panel-action="min"]');if(b){b.textContent=value==='min'?'+':'−';b.title=(value==='min'?'Restore':'Minimise')+' '+label;b.setAttribute('aria-label',b.title);b.setAttribute('aria-expanded',String(value!=='min'));}
  }
  // Preserve the canvas when either side is hidden. A minimised equipment menu is a narrow rail.
  const work=document.getElementById('workspace-panel');
  work.style.setProperty('--setup-width',prefs.equipment==='hide'?'0px':prefs.equipment==='min'?'48px':'220px');
  work.style.setProperty('--right-width',prefs.inspector==='hide'&&prefs.staging==='hide'?'0px':'270px');
  work.style.setProperty('--inspector-row',prefs.inspector==='hide'?'0px':prefs.inspector==='min'?'auto':'minmax(0,1fr)');
  work.style.setProperty('--staging-row',prefs.staging==='hide'?'0px':prefs.staging==='min'?'auto':'minmax(105px,.65fr)');
  hiddenPanels.replaceChildren();for(const [id,,label]of panels){if(!['hide','min'].includes(prefs[id]))continue;const b=document.createElement('button');b.type='button';b.textContent='Show '+label;b.onclick=()=>set(id,'open');hiddenPanels.append(b);}hiddenPanels.hidden=!hiddenPanels.children.length;restore.hidden=!panels.some(([id])=>['hide','min'].includes(prefs[id]));
  window.dispatchEvent(new Event('resize'));
 }
 menu.querySelectorAll('[data-layout]').forEach(s=>s.onchange=()=>set(s.dataset.layout,s.value));
 menu.querySelector('#layout-reset').onclick=()=>{prefs={};try{localStorage.removeItem(key);}catch{}apply();};
 document.addEventListener('click',e=>{if(!menu.contains(e.target))menu.open=false;});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')menu.open=false;});
 window.addEventListener('truck-ui-render',apply);
 apply();
})();
