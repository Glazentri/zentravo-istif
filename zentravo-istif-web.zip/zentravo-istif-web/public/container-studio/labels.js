/* Cargo identification shared by the workspace, load drawing and printed labels. */
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=n=>Number(n).toLocaleString('en-AU',{maximumFractionDigits:1,useGrouping:false});
const handlingIcon=type=>`<svg viewBox="0 0 32 32" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">${type==='upright'?'<path d="M9 23V5m-5 5 5-5 5 5M23 23V5m-5 5 5-5 5 5M4 28h24"/>':'<path d="M7 18h18v10H7zM10 4h12v9H10z"/><path d="M3 3l26 26" stroke-width="3.4"/>'}</svg>`;
export function resolveLabelBrand(plan,item){
 const profiles=plan.labelBranding||[];
 const profile=profiles.find(p=>p.supplier===item.supplier)||profiles.find(p=>p.supplier==='');
 return {name:profile?.name||item.supplier||'',logo:profile?.logo||''};
}
export function cargoLabelHTML(item,{ref='',container='Unplaced',step=null,index=1,total=1,color='#226c57',brand={}}={}){
 const dimensions=[item.l,item.w,item.h].map(num).join(' × '),handling=[];
 if(item.rotation!=='free')handling.push('<span>'+handlingIcon('upright')+' KEEP UPRIGHT</span>');
 handling.push(item.stackable&&item.maxTopLoad!==null?'<span><b>⇣</b> MAX TOP LOAD '+num(item.maxTopLoad)+' kg</span>':'<span class="handling-danger">'+handlingIcon('no-stack')+' DO NOT STACK ON TOP</span>');
 if(item.floorOnly)handling.push('<span><b>▰</b> FLOOR ONLY</span>');
 return `<section class="cargo-label" style="--cargo-color:${color}"><header class="cargo-label-head ${brand.name||brand.logo?'supplier-branded':''}"><div class="cargo-label-brand">${brand.logo?`<img src="${esc(brand.logo)}" alt="${esc(brand.name||'Supplier')} logo">`:''}<strong>${brand.name?esc(brand.name):'ZENTRAVO <span>BY GLAZENTRI</span>'}</strong></div><span>CARGO & HANDLING</span></header><div class="cargo-label-route"><span>SHIPMENT<strong>${esc(ref)}</strong></span><span>PACKAGE<strong>${index} / ${total}</strong></span></div><div class="cargo-label-identity"><span class="cargo-label-category">${esc(item.category)} · ${esc(item.packaging)}</span><h2>${esc(item.label)}</h2><p>${esc(item.consignment||'Home 1')}${item.room?' · '+esc(item.room):''}</p></div><div class="cargo-label-stats"><div><small>OUTER L × W × H · mm</small><strong>${dimensions}</strong></div><div><small>GROSS WEIGHT</small><strong>${item.weight===null?'TO BE CONFIRMED':num(item.weight)+' kg'}</strong><small>${esc(item.weightSource||'Unknown')}</small></div></div><div class="cargo-label-handling">${handling.join('')}</div><div class="cargo-label-destination"><div><small>CONTAINER / LOAD STEP</small><strong>${esc(container)}${step===null?'':' · '+String(step).padStart(2,'0')}</strong></div><div><small>SUPPLIER</small><strong>${esc(item.supplier||'To be confirmed')}</strong></div></div>${item.contents?.length?'<div class="cargo-label-contents"><small>CRATE CONTENTS · '+item.contents.length+' PACKAGES</small><p>'+item.contents.map(c=>esc(c.label)).join(' · ')+'</p></div>':''}${item.notes?'<div class="cargo-label-notes"><small>HANDLING NOTES</small><p>'+esc(item.notes)+'</p></div>':''}<footer class="cargo-label-foot"><span>Zentravo by Glazentri · Identify · Check · Load</span><span>REF ${esc(item.id)}</span></footer></section>`;
}
export function cargoTopLabelSVG(item,p,color){
 const width=p.uzunluk,height=p.en,vertical=height>width*1.5;
 const w=vertical?height:width,h=vertical?width:height;
 const font=Math.max(12,Math.min(125,h*.26,w/Math.max(7,item.label.length*.6))),pad=Math.min(w,h)*.08;
 const details=h>font*4.8;
 return `<g transform="translate(${p.z+width/2} ${p.x+height/2})${vertical?' rotate(-90)':''}" pointer-events="none"><rect x="${-w/2+pad}" y="${-font*(details?1.5:.9)}" width="${w-2*pad}" height="${font*(details?3:1.8)}" rx="${font*.28}" fill="#f9fcfa" fill-opacity=".94" stroke="#244137" stroke-width="${Math.min(10,font*.06)}"/><rect x="${-w/2+pad}" y="${-font*(details?1.5:.9)}" width="${font*.18}" height="${font*(details?3:1.8)}" fill="${color}"/><text text-anchor="middle" y="${details?-font*.2:font*.32}" font-family=Arial, sans-serif" font-size="${font}" font-weight="700" fill="#17372d">${esc(item.label)}</text>${details?`<text text-anchor="middle" y="${font*.85}" font-family=Arial, sans-serif" font-size="${font*.6}" fill="#48675c">${esc(item.packaging)} · ${item.weight===null?'Weight TBC':num(item.weight)+' kg'}</text>`:''}</g>`;
}
export function cargoTopCanvas(item,length,width,color){
 const c=document.createElement('canvas'),scale=Math.min(1,1024/Math.max(length,width));
 c.width=Math.max(32,Math.round(length*scale));c.height=Math.max(32,Math.round(width*scale));
 const x=c.getContext('2d');if(!x)return null;
 const vertical=c.height>c.width*1.5;if(vertical){x.translate(c.width,0);x.rotate(Math.PI/2);}
 const w=vertical?c.height:c.width,h=vertical?c.width:c.height;
 if(!item.stackable){x.strokeStyle='#24413744';x.lineWidth=2;for(let n=-h;n<w+h;n+=22){x.beginPath();x.moveTo(n,0);x.lineTo(n+h,h);x.stroke();}}
 const cw=w*.88,ch=Math.min(h*.8,w*.38),left=(w-cw)/2,top=(h-ch)/2;
 x.fillStyle='#f9fcfa';x.beginPath();x.roundRect(left,top,cw,ch,Math.min(ch*.14,12));x.fill();
 x.fillStyle=color;x.fillRect(left,top,Math.max(3,ch*.045),ch);
 let size=Math.min(ch*.36,60);while(size>8){x.font=`700 ${size}px Arial, sans-serif`;if(x.measureText(item.label).width<cw*.9)break;size--;}
 x.textAlign='center';x.textBaseline='middle';x.fillStyle='#17372d';const details=ch>size*2.8;
 x.fillText(item.label,w/2,top+ch*(details?.4:.52),cw*.9);
 if(details){x.font=`500 ${Math.max(8,size*.55)}px Arial, sans-serif`;x.fillStyle='#48675c';x.fillText(item.packaging+' · '+(item.weight===null?'Weight TBC':num(item.weight)+' kg'),w/2,top+ch*.76,cw*.9);}
 return c;
}
