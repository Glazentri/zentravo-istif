import {applyEngine, engineInput, orderPlacements, orientations, placeOne, retainedForOptimise, validateLayout} from './core.js';
import {planla} from './vendor/istif/js/motor/motor.js';

function rank(plan) {
  const occupied = new Map();
  let volume = 0;
  for (const p of plan.placements) {
    occupied.set(p.containerId, Math.max(occupied.get(p.containerId) || 0, p.z + p.uzunluk));
    volume += p.en * p.yukseklik * p.uzunluk;
  }
  const conflicts = validateLayout(plan).issues.filter(i => i.severity === 'warning').length;
  const preferred = new Set(plan.items.filter(i=>i.strapWindow).map(i=>i.id));
  const stacked = plan.placements.filter(p=>p.y>0 && preferred.has(p.id)).length;
  return [-plan.placements.length, conflicts, -volume, occupied.size, -stacked, [...occupied.values()].reduce((a,b)=>a+b,0)];
}

function isBetter(candidate, existing) {
  const next = rank(candidate), current = rank(existing);
  const first = current.findIndex((v,k) => v !== next[k]);
  return first >= 0 && next[first] < current[first];
}

function fillAround(plan, preferWide, deadline, options={}) {
  const placed = new Set(plan.placements.map(p => p.id));
  const todo = plan.items.filter(i => !placed.has(i.id)).sort((a,b) =>
    b.delivery-a.delivery || Number(!!a.strapWindow)-Number(!!b.strapWindow) || Number(!!a.sideBracePlanned&&!a.stackable)-Number(!!b.sideBracePlanned&&!b.stackable) || (options.lightFirst ? (a.weight??Infinity)-(b.weight??Infinity) : 0) || b.l*b.w-a.l*a.w || Number(b.stackable)-Number(a.stackable));
  for (const [index,item] of todo.entries()) {
    if (performance.now() >= deadline) break;
    const stacked = item.strapWindow && plan.containers.some(c => placeOne(plan,item.id,c.id,{respectStops:true,stackOnly:true,edgeStack:options.edgeStack}));
    if (!stacked) for (const c of plan.containers) if (placeOne(plan,item.id,c.id,{respectStops:true,preferWide,floorFallback:!!item.strapWindow})) break;
    postMessage({progress:Math.round((index+1)*100/todo.length)});
  }
  const check = orderPlacements(plan);
  if (!check.valid) throw Error(check.issues.find(i => i.severity === 'error').message);
}

// On a small lattice, pick the package or floor cell with the fewest legal options.
// Integer grid cells describe candidate coordinates only. Returned cargo dimensions
// and locked placements retain their original millimetre values.
function tiledGrid(plan,c,fixed,pending,deadline) {
  const width=c.width-2*c.wallGap,depth=c.length-c.rearReserve-c.wallGap;
  function cellSize(values) {
    let unit=0;
    for(const value of values){
      const scaled=Math.round(value*1000);
      if(!Number.isSafeInteger(scaled)||Math.abs(value*1000-scaled)>1e-6)return 0;
      let next=Math.abs(scaled);
      while(next){const rest=unit%next;unit=next;next=rest;}
    }
    return unit/1000;
  }
  const choices=pending.flatMap(p=>p.choices);
  const sx=cellSize([width,...choices.map(v=>v[0]),...fixed.flatMap(p=>[p.x-c.wallGap,p.en])]);
  const sz=cellSize([depth,...choices.map(v=>v[2]),...fixed.flatMap(p=>[p.z-c.wallGap,p.uzunluk])]);
  if(!sx||!sz)return null;
  const cols=Math.round(width/sx),rows=Math.round(depth/sz),cells=cols*rows;
  if(cells>240||cols<1||rows<1)return null;
  const blocked=new Uint8Array(cells);
  for(const p of fixed){
    const x=Math.round((p.x-c.wallGap)/sx),z=Math.round((p.z-c.wallGap)/sz),w=Math.round(p.en/sx),d=Math.round(p.uzunluk/sz);
    if(p.y!==0||x<0||z<0||x+w>cols||z+d>rows)return null;
    for(let r=z;r<z+d;r++)for(let i=x;i<x+w;i++){
      const cell=r*cols+i;if(blocked[cell])return null;blocked[cell]=1;
    }
  }
  // Each option covers one package and every cell of its footprint. Count the
  // available options for each uncovered requirement as rows are removed/restored.
  const columnFor=new Uint16Array(cells);let headers=pending.length;
  for(let i=0;i<cells;i++)if(!blocked[i])columnFor[i]=++headers;
  const left=[],right=[],above=[],below=[],column=[],row=[],sizes=new Uint16Array(headers+1),options=[];
  for(let i=0;i<=headers;i++){
    left[i]=i===0?headers:i-1;right[i]=i===headers?0:i+1;above[i]=below[i]=i;
  }
  let nodes=headers;
  const shapeGroups=new Map(),symmetry=[];
  function addRow(headersToCover,pose,equivalent){
    const first=nodes+1,id=options.push(pose)-1;symmetry[id]=equivalent;
    for(const h of headersToCover){
      const n=++nodes;column[n]=h;row[n]=id;sizes[h]++;
      above[n]=above[h];below[n]=h;below[above[h]]=n;above[h]=n;
      left[n]=n-1;right[n]=n+1;
    }
    left[first]=nodes;right[nodes]=first;
  }
  for(const [i,{item,choices}] of pending.entries()){
    const key=JSON.stringify(choices);
    if(!shapeGroups.has(key))shapeGroups.set(key,shapeGroups.size);
    const group=shapeGroups.get(key);
    for(const [orientation,[en,yukseklik,uzunluk]] of choices.entries()){
      const w=Math.round(en/sx),d=Math.round(uzunluk/sz);
      if(w<1||d<1)return null;
      for(let z=0;z+d<=rows;z++){
        if(performance.now()>=deadline)return null;
        for(let x=0;x+w<=cols;x++){
          const footprint=[i+1];let fits=true;
          for(let r=z;r<z+d&&fits;r++)for(let s=x;s<x+w;s++){
            const h=columnFor[r*cols+s];if(!h){fits=false;break;}footprint.push(h);
          }
          if(fits){
            if(nodes+footprint.length>50000)return null;
            addRow(footprint,{id:item.id,containerId:c.id,x:c.wallGap+x*sx,y:0,z:c.wallGap+z*sz,en,yukseklik,uzunluk},(group*6+orientation)*cells+z*cols+x);
          }
        }
      }
    }
  }
  function cover(h){
    right[left[h]]=right[h];left[right[h]]=left[h];
    for(let r=below[h];r!==h;r=below[r])for(let n=right[r];n!==r;n=right[n]){
      below[above[n]]=below[n];above[below[n]]=above[n];sizes[column[n]]--;
    }
  }
  function uncover(h){
    for(let r=above[h];r!==h;r=above[r])for(let n=left[r];n!==r;n=left[n]){
      sizes[column[n]]++;below[above[n]]=n;above[below[n]]=n;
    }
    right[left[h]]=h;left[right[h]]=h;
  }
  const placements=[...fixed];let visits=0,expired=false;
  function search(){
    if(++visits>12000||performance.now()>=deadline){expired=true;return false;}
    if(!right[0])return true;
    let best=right[0];
    for(let h=right[best];h;h=right[h])if(sizes[h]<sizes[best])best=h;
    if(!sizes[best])return false;
    cover(best);
    // Equal, unlocked floor packages are interchangeable at the same position.
    const tried=best>pending.length&&shapeGroups.size<pending.length?new Set():null;
    for(let r=below[best];r!==best;r=below[r]){
      const equivalent=symmetry[row[r]];
      if(tried?.has(equivalent))continue;
      tried?.add(equivalent);
      placements.push(options[row[r]]);
      for(let n=right[r];n!==r;n=right[n])cover(column[n]);
      if(search())return true;
      for(let n=left[r];n!==r;n=left[n])uncover(column[n]);
      placements.pop();if(expired)break;
    }
    uncover(best);return false;
  }
  return search()?placements:null;
}

// A small, fully tiled floor has no gaps. At the first uncovered point from the
// nose and left wall, one remaining rectangle must start exactly there. This
// bounded search also works around existing packages and fractional dimensions.
function completeTiledFloor(plan,fixed,deadline) {
  if (plan.containers.length!==1 || plan.items.length>20 || !plan.items.length) return null;
  const c=plan.containers[0], stop=plan.items[0].delivery;
  if (plan.items.some(i=>!i.floorOnly || i.rotation==='free' || i.delivery!==stop)) return null;
  const area=plan.items.reduce((sum,i)=>sum+i.l*i.w,0);
  const right=c.width-c.wallGap, end=c.length-c.rearReserve;
  if (Math.abs(area-(right-c.wallGap)*(end-c.wallGap))>1e-5 ||
      plan.items.reduce((kg,i)=>kg+(i.weight??0),0)>c.payload+1e-9) return null;
  const placements=[...fixed], placed=new Set(fixed.map(p=>p.id));
  const pending=plan.items.filter(i=>!placed.has(i.id)).sort((a,b)=>b.l*b.w-a.l*a.w).map(item=>({
    item, choices:orientations(item).filter(([w,h,l])=>w<=c.doorWidth && h<=Math.min(c.doorHeight,c.height-c.wallGap))
  }));
  const grid=tiledGrid(plan,c,fixed,pending,Math.min(deadline,performance.now()+140));
  if(grid){
    const candidate={...plan,placements:grid};
    if(orderPlacements(candidate).valid)return candidate;
  }
  let nodes=0;
  function search() {
    if(++nodes>20000 || performance.now()>=deadline) return false;
    if(placements.length===plan.items.length) return true;
    const depths=[...new Set([c.wallGap,...placements.map(p=>p.z+p.uzunluk)])].sort((a,b)=>a-b);
    for(const z of depths){
      if(z>=end) break;
      let x=c.wallGap;
      const row=placements.filter(p=>p.z<=z && z<p.z+p.uzunluk).sort((a,b)=>a.x-b.x);
      for(const p of row){if(p.x>x) break;x=Math.max(x,p.x+p.en);}
      if(x>=right) continue;
      const tried=new Set();
      for(const {item,choices} of pending){
        if(placed.has(item.id)) continue;
        for(const [en,yukseklik,uzunluk] of choices){
          const key=[en,yukseklik,uzunluk,item.rotation].join(',');
          if(tried.has(key)) continue;
          tried.add(key);
          if(x+en>right || z+uzunluk>end || placements.some(p=>x<p.x+p.en && p.x<x+en && z<p.z+p.uzunluk && p.z<z+uzunluk)) continue;
          placed.add(item.id);placements.push({id:item.id,containerId:c.id,x,y:0,z,en,yukseklik,uzunluk});
          if(search()) return true;
          placements.pop();placed.delete(item.id);
          if(nodes>20000) return false;
        }
      }
      return false;
    }
    return false;
  }
  if(!search()) return null;
  const candidate={...plan,placements};
  return orderPlacements(candidate).valid ? candidate : null;
}

self.onmessage = ({data:{plan,mode}}) => {
  try {
    const fixed = mode === 'optimise' ? retainedForOptimise(plan) : plan.placements;
    let candidate = {...plan,placements:[...fixed]};
    // The fast search uses integer-mm cells and independent vehicle payloads.
    const needsExactSearch = plan.items.some(i => i.strapWindow || (i.category==='Windows'&&!i.floorOnly) || ![i.l,i.w,i.h].every(Number.isInteger)) ||
      plan.containers.some(c => c.combinationGroup || ![c.wallGap,c.rearReserve].every(Number.isInteger));
    if (candidate.placements.length || needsExactSearch) {
      const start = performance.now();
      fillAround(candidate,false,start+18000);
      const edgeStack=plan.items.filter(i=>i.strapWindow).length>1;
      const capacities=new Map();
      for(const c of plan.containers){
        const group=c.combinationGroup||c.id;
        capacities.set(group,Math.min(capacities.get(group)??Infinity,c.payload));
      }
      const lightFirst=plan.items.reduce((kg,i)=>kg+(i.weight??0),0)>[...capacities.values()].reduce((a,b)=>a+b,0);
      const canRotate=plan.items.some(i=>i.rotation!=='fixed' && i.w!==i.l);
      if (candidate.placements.length < plan.items.length && (canRotate || edgeStack || lightFirst)) {
        const alternative = {...plan,placements:[...fixed]};
        fillAround(alternative,true,start+35000,{edgeStack,lightFirst});
        if (isBetter(alternative,candidate)) candidate = alternative;
      }
    }
    else applyEngine(candidate,planla(engineInput(candidate,true),{ilerleme:progress=>postMessage({progress})}));
    if (candidate.placements.length < plan.items.length) {
      candidate=completeTiledFloor(plan,fixed,performance.now()+200) || candidate;
    }
    if (mode === 'optimise' && plan.placements.length && !isBetter(candidate,plan)) candidate = plan;
    postMessage({plan:candidate});
  } catch (error) {
    postMessage({error:error.message});
  }
};
