# WinMatch whole-of-home cargo workspace

The workspace integrates İstif's MIT-licensed placement engine, Three.js scene and editing geometry with WinMatch projects. See vendor/istif/PROVENANCE.md for the pinned upstream version and licence.

## Data and integration

- Project storage: `state.p.containerPlannerPro`, included in normal project saves and JSON backups. The isolated workspace sends changes over a same-origin, per-mount message channel; the parent checks the active project identity and confirms browser persistence.
- Units: millimetres and kilograms. Scene axes: x across the container, y above its floor, z along it from the nose. IFC conversion maps z → X, x → Y, y → Z.
- Every physical package has its own ID, dimensions, gross mass, supplier, consignment, handling constraints and position. Crates retain nested contents and original schedule-unit references.
- Schedule imports add missing units without duplicating units already grouped in a crate. Changed source dimensions flag a review; confirmed package dimensions and placements are preserved.
- Unknown weights remain unknown. Gross weight includes packaging; a grouped crate initially needs a gross weight or an explicit contents-plus-tare calculation.
- Auto-pack preserves placed packages. Optimise retains locked packages and supports below them. All accepted edits pass bounds, door opening, collision, orientation, payload, support and rated top-load checks.
- Project IFC and drawing exports use the new plan. Site-planner unloading receives the new package list in reverse loading order. Old site imagery, annotations and delivery tools remain available.

## Build and verify

`node scripts/build-container-studio.mjs` bundles the local worker and renderer. This also runs in the main production build. No third-party service receives shipment data.

Checks:
- `node qa/container-studio-checks.mjs`
- `node qa/container-project-bridge-checks.cjs`
- `node public/container-studio/vendor/istif/tests/motor.test.mjs`
- `node qa/container-ifc-checks.cjs`
- `node qa/container-export-checks.cjs`
- `node qa/container-weight-checks.cjs`
- `node qa/takeoff-schedule-bands-checks.cjs`

Browser QA covers mixed cargo, grouping contents into a crate, contents-plus-tare mass, placement, dragging, rotation, undo, saved-layout reload, embedded project save, IFC download, site-unloading connection, and a 390 px layout without horizontal overflow. The cloud QA browser disables WebGL; the interactive SVG top-plan fallback was exercised. The GPU-rendered 3D view and animated loading still require a WebGL-capable browser smoke check.

## Planning limits

Container presets are editable nominal envelopes. Confirm booked equipment and actual packaging dimensions. Upright windows are protected by default; arbitrary cargo can use other allowed orientations. Max 300 top-level shipping packages and 20 containers. Packing is a heuristic, not a proof of optimum utilisation. Fit and stack checks do not certify cargo restraint, crate engineering, lifting, carrier approval, axle loading or a continuous insertion path through the door. Crate grouping proposes a side-by-side envelope and requires confirmation of actual outer dimensions.

## Truck delivery and route planning
The Truck delivery & route tab reuses top-level shipment packages by ID, preserving crate dimensions and skipping unweighed packages. Consignments map to Site A/B for separate delivery trips; the imported destinations remain editable. Import is explicit and repeatable without duplicates. The delivery draft persists inside `containerPlannerPro.truckDelivery`, normal project saves, cloud revisions and cargo JSON exports/imports. Floor-only upright truck fit, editable vehicle examples and manual/forklift/combined cost comparisons are planning allowances.

Address-based route legs load a Google directions iframe only on Preview directions. Users paste a km/time summary (for example `42 km, 50 min`), which updates drive time and fuel; repeated runs and unloading stop minutes are included. No mapping API key is required. Provider distance/time is not read automatically across the iframe. Optional coordinate estimates remain under Advanced. Fuel is kept separate from quoted carrier costs to avoid double counting. External map previews send only that leg’s addresses to the map provider; cargo remains local.
