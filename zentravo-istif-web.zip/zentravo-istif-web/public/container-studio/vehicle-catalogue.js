/* Equipment shapes and indicative mass references do not establish a booked vehicle's ratings. */
(function(root){
const source='https://statetransport.com.au/vehicle-types/';
const licenceSource='https://www.qld.gov.au/transport/licensing/driver-licensing/types';
const massSource='https://www.nhvr.gov.au/road-access/mass-and-dimension/mass-limits/manufacturers-mass-limits';
const classes=['C','LR','MR','HR','HC','MC'];

// Guide ranges were transcribed from the Australian Vehicle GVM, GCM & Container Weight Reference.
const references={
 'truck-light':{gvm:'Over 4.5 t to 8.0 t',licence:'LR',axles:'2 axles shown'},
 'truck-medium':{gvm:'Over 8.0 t',licence:'MR',axles:'2 axles'},
 'truck-heavy':{gvm:'Over 8.0 t',licence:'HR',axles:'3 or more axles'},
 'fleet-van-1':{gvm:'3.0–3.5 t',licence:'C'},
 'fleet-van-2':{gvm:'4.49 t derated or 5.0–5.2 t',licence:'C or LR'},
 'fleet-tray-1':{gvm:'3.0–3.5 t',licence:'C'},
 'fleet-tray-2':{gvm:'4.495 t derated or 5.5–6.5 t',licence:'C or LR'},
 'fleet-taut-4':{gvm:'8.0–8.7 t',licence:'LR or MR',axles:'Typically 2 axles'},
 'fleet-taut-6':{gvm:'10.4–12.0 t',licence:'MR',axles:'Typically 2 axles'},
 'fleet-taut-8':{gvm:'14.0–16.0 t',licence:'MR',axles:'Typically 2 axles'},
 'fleet-taut-12':{gvm:'22.5–24.0 t',licence:'HR',axles:'Typically 3 axles'},
 'fleet-taut-14':{gvm:'24.0–30.0 t',licence:'HR',axles:'Typically 3 or 4 axles'}
};
const makerReferences={
 'fleet-van-1':{name:'Toyota HiAce LWB van',gvm:3300,url:'https://www.toyota.com.au/-/media/toyota/main-site/vehicle-hubs/hiace/files/20250828_hiace_spec-sheet.pdf'},
 'truck-light':{name:'Hino 300 816 Wide Cab (8 t configuration)',gvm:8000,url:'https://www.hino.com.au/uploads/pdf/specification/300-series/hsmy20816-917w-0720%20web.pdf'},
 'truck-medium':{name:'Fuso Fighter 1224 Euro 6 FK',gvm:12000,url:'https://www.fuso.com.au/range/fighter/fk/1224-manual/'},
 'truck-heavy':{name:'Isuzu FVZ 240-300 6×4',gvm:24000,url:'https://www.isuzu.com.au/Media/Isuzu_Files/Spec_Sheets/Current_spec_sheets/Spec_FVZ_FVY_240_300_2311R.pdf'},
 'truck-semi':{name:'Fuso Shogun FV74 510 prime mover (optional ratings)',gvm:26000,gcm:63000,url:'https://www.fuso.com.au/siteassets/media/documents/spec-sheets/shogun/shogun-fv74-510-prime-mover.pdf'}
};
const vehicles=[
{id:'truck-light',name:'Light rigid truck',body:'tray',type:'kamyonet',length:4200,width:2100,height:2200,payload:2500,displayAxles:2,configuration:'rigid',example:true},
{id:'truck-medium',name:'Medium rigid truck',body:'tautliner',type:'kamyon',length:6000,width:2400,height:2400,payload:6000,displayAxles:2,configuration:'rigid',example:true},
{id:'truck-heavy',name:'Heavy rigid truck',body:'tautliner',type:'kamyon',length:8000,width:2400,height:2600,payload:10000,displayAxles:3,configuration:'rigid',example:true},
{id:'truck-semi',name:'Semi trailer',body:'tautliner',type:'tir',length:13000,width:2400,height:2700,payload:22000,displayAxles:3,configuration:'semi',example:true},
...[
['van-1','One Tonne Van',2000,1200,0,1000,'van','rigid'],['van-2','Two Tonne Van',3000,1800,2,2000,'van','rigid'],
['tray-1','One Tonne Tray',2400,1200,1,1000,'tray','rigid'],['tray-2','Two Tonne Tray',2400,1800,2,2000,'tray','rigid'],
['taut-4','Four Tonne Tautliner',2400,2400,4,4000,'tautliner','rigid'],['taut-6','Six Tonne Tautliner',3600,2400,6,6000,'tautliner','rigid'],
['taut-8','Eight Tonne Tautliner',4800,2400,8,8000,'tautliner','rigid'],['taut-12','Twelve Tonne Tautliner',7200,2400,12,12000,'tautliner','rigid'],
['taut-14','Fourteen Tonne Tautliner',8400,2400,14,14000,'tautliner','rigid'],['taut-22','Twenty-two Tonne Tautliner',13200,2400,22,22000,'tautliner','semi'],
['taut-24','Twenty-four Tonne Tautliner',14400,2400,24,24000,'tautliner','semi'],
['bdouble','B Double',20400,2400,34,22000,'tautliner','bdouble'],['mezzanine','38 pallet Mezzanine',13200,2400,38,22000,'mezzanine','semi']
].map(([id,name,length,width,pallets,payload,body,configuration])=>({
 id:'fleet-'+id,name,body,type:configuration==='rigid'?(body==='van'||body==='tray'?'kamyonet':'kamyon'):'tir',
 length,width,height:body==='van'?1800:2700,payload,configuration,pallets,source,example:true,
 assumptions:id==='bdouble'?'Use the separate trailer deck dimensions.':id==='mezzanine'?'The advertised 38 pallets includes mezzanine capacity. The planner models floor loading.':''
}))
].map(v=>({...v,gvm:null,gcm:null,axles:null,vehicleReference:v.id}));
function requiredClass(v){
 if(v.configuration==='bdouble'||v.configuration==='roadtrain')return 'MC';
 if(v.configuration==='semi')return 'HC';
 const g=Number(v.gvm);
 if(!Number.isFinite(g)||g<=0)return null;
 if(Number(v.trailerGvm)>9000)return g>8000?'HC':null;
 if(g<=4500)return 'C';
 if(g<=8000)return 'LR';
 const a=Number(v.axles);
 return Number.isInteger(a)&&a>=2&&a<=12?(a===2?'MR':'HR'):null;
}
function licenceCheck(held,v){
 const required=requiredClass(v);
 return {required,allowed:required&&classes.includes(held)?classes.indexOf(held)>=classes.indexOf(required):null};
}
const definitions={C:'Up to 4.5 t GVM.',LR:'Over 4.5 t and up to 8 t GVM.',MR:'Over 8 t GVM, 2 axles.',HR:'Over 8 t GVM, 3 or more axles.',HC:'Prime mover with a semi-trailer, or a truck over 8 t GVM towing a trailer over 9 t GVM.',MC:'B-double or other multi-combination.'};
function referenceFor(v){
 const key=v.vehicleReference||v.id||v.preset;
 return {
  range:Object.hasOwn(references,key)?references[key]:null,
  maker:Object.hasOwn(makerReferences,key)?makerReferences[key]:null
 };
}
function optionLabel(v){
 const {range}=referenceFor(v);
 if(range)return v.name+' · '+range.licence+' example';
 const licence=requiredClass(v);
 return v.name+' · '+(licence||'GVM to confirm');
}
function massReferenceHTML(v){
 const {range,maker}=referenceFor(v);
 const combination=v.configuration==='semi'||v.configuration==='bdouble'||v.configuration==='roadtrain';
 const illustrative=range?'<p><strong>GVM reference:</strong> '+range.gvm+' · '+range.licence+' guide'+(range.axles?' · '+range.axles:'')+'</p>':'<p><strong>Confirm '+(combination?'prime mover GVM and combination GCM':'the booked vehicle GVM')+' with your carrier.</strong></p>';
 const kg=new Intl.NumberFormat('en-AU');
 const model=maker?'<small><a href="'+maker.url+'" target="_blank" rel="noopener noreferrer">'+maker.name+'</a> · '+kg.format(maker.gvm)+' kg GVM'+(maker.gcm?' · '+kg.format(maker.gcm)+' kg GCM':'')+' · manufacturer example</small>':'';
 return '<div class="vehicle-mass-reference">'+illustrative+model+'</div>';
}
root.VehicleCatalogue={vehicles,classes,requiredClass,licenceCheck,definitions,referenceFor,optionLabel,massReferenceHTML,source,licenceSource,massSource};
})(globalThis);
