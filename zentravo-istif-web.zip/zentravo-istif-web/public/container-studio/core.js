/* WinMatch shipment model and Istif integration. Dimensions mm; mass kg.
 * Scene axes: x = width from left, y = height from floor, z = length from nose. */
import './vehicle-catalogue.js';
import {denetle, kalanBosluk, ustundekiler} from './vendor/istif/js/motor/motor.js';
export const SCHEMA = 'winmatch-cargo/1';
export const PRESETS = {
  '20gp': {name:'20 ft General Purpose',length:5898,width:2352,height:2393,doorWidth:2340,doorHeight:2280,payload:28200},
  '40gp': {name:'40 ft General Purpose',length:12032,width:2352,height:2393,doorWidth:2340,doorHeight:2280,payload:26700},
  '40hc': {name:'40 ft High Cube',length:12032,width:2352,height:2698,doorWidth:2340,doorHeight:2585,payload:26500},
  '45hc': {name:'45 ft High Cube',length:13556,width:2352,height:2698,doorWidth:2340,doorHeight:2585,payload:27600}
};
export const TRUCK_PRESETS = Object.fromEntries(globalThis.VehicleCatalogue.vehicles.map(({id,...v})=>[id,{...v,length:v.configuration==='bdouble'?7800:v.length}]));
for (const [key,v] of Object.entries(TRUCK_PRESETS)) PRESETS[key]={...v,doorWidth:v.width,doorHeight:v.height,wallGap:0,rearReserve:0};
export const CATEGORIES = {
  Windows:'#4ba88b', Doors:'#6b9dd6', Cabinetry:'#c69b65', Benchtops:'#aa93cc',
  'Tiles & stone':'#d48e72', Electrical:'#dbb861', 'Curtains & blinds':'#8fbea7',
  Plumbing:'#61b7bf', Appliances:'#7e9daf', Flooring:'#aaaf73', 'Custom cargo':'#b7a3a5'
};
export const uid = () => globalThis.crypto?.randomUUID?.() || 'pkg-'+Date.now().toString(36)+Math.random().toString(36).slice(2);
export const clone = x => structuredClone(x);
export function newContainer(preset='40hc',n=1){return {id:uid(),preset,wallGap:20,rearReserve:150,...PRESETS[preset],name:(TRUCK_PRESETS[preset]?'Truck ':'Container ')+n};}
export function blankPlan(){return {schema:SCHEMA,ref:'New shipment',notes:'',labelBranding:[],containers:[newContainer()],items:[],placements:[],updatedAt:new Date().toISOString()};}
function handlingRotation(item) {
  if (item.rotation==='free' && ['Windows','Doors'].includes(item.category)) return 'upright';
  return ['upright','fixed','free'].includes(item.rotation) ? item.rotation : 'upright';
}
export function newItem(data={}){return {id:uid(),label:'New package',category:'Custom cargo',packaging:'Carton',supplier:'',consignment:'Home 1',room:'',l:1200,w:800,h:800,weight:null,weightSource:'Unknown',tare:0,rotation:'upright',stackable:false,maxTopLoad:null,floorOnly:true,delivery:1,locked:false,notes:'',contents:[],sources:[],...data};}
export function asCargo(i){return {id:i.id,ad:i.label,adet:1,en:i.w,yukseklik:i.h,uzunluk:i.l,agirlik:i.weight??0,donus:{upright:'dik',fixed:'sabit',free:'serbest'}[handlingRotation(i)]||'dik',ustuneKonabilir:i.stackable&&i.maxTopLoad!==null,ustYukSiniri:i.maxTopLoad??0,yalnizZemin:i.floorOnly||i.weight===null,teslimatSirasi:i.delivery,renk:CATEGORIES[i.category]||CATEGORIES['Custom cargo']};}
export function asVehicle(c,usable=false){const g=usable?c.wallGap:0;return {ad:c.name,tur:c.type||PRESETS[c.preset]?.type||'konteyner',en:c.width-2*g,yukseklik:c.height-g,uzunluk:c.length-g,maksAgirlik:c.payload,kapiPayiMm:c.rearReserve,doorWidth:c.doorWidth,doorHeight:c.doorHeight,body:c.body||PRESETS[c.preset]?.body,axles:c.axles||TRUCK_PRESETS[c.vehicleReference||c.preset]?.displayAxles,configuration:c.configuration||PRESETS[c.preset]?.configuration};}
export function engineInput(plan,usable=false){return {filo:plan.containers.map(c=>({...asVehicle(c,usable),ad:c.id})),cokluArac:false,kalemler:plan.items.map(asCargo),secenekler:{destekOrani:1,dengele:false,sureButcesiMs:6000}};}
export function sceneItems(plan,cid){return plan.placements.filter(p=>p.containerId===cid).map((p,index)=>{const i=plan.items.find(i=>i.id===p.id);return {...p,kalemId:p.id,parcaNo:1,ad:i.label,agirlik:i.weight??0,renk:CATEGORIES[i.category]||'#b7a3a5',sira:index+1,packaging:i.packaging,category:i.category,locked:i.locked};});}
const ERRORS={tasma:'Outside the container or door reserve',donus:'Rotation is not allowed for this package',cakisma:'Packages overlap',yalnizZemin:'This package must stay on the floor',destek:'Package needs full support beneath it',ustuneKonamaz:'Cargo is above a non-stackable package',ustYuk:'The rated load above a package is exceeded',teslimatSirasi:'Delivery order is blocked by another package',tonaj:'Maximum payload is exceeded'};
export function validateLayout(plan){
  const issues=[];const seen=new Set();
  const itemsById=new Map(plan.items.map(item=>[item.id,item]));
  for(const p of plan.placements){
    const i=itemsById.get(p.id),c=plan.containers.find(c=>c.id===p.containerId);
    if(!i||!c||seen.has(p.id)){issues.push({id:p.id,message:'Missing or duplicate package/container',severity:'error'});continue;}seen.add(p.id);
    if(![p.x,p.y,p.z,p.en,p.yukseklik,p.uzunluk].every(Number.isFinite)){issues.push({id:p.id,message:'Invalid package coordinates',severity:'error'});continue;}
    if (i.category==='Windows' && p.y>0 && !windowSideSupports(plan,i,p).every(Boolean)) {
      issues.push({id:p.id,code:'window-side-support',message:lateralSupportIssue,severity:'error'});
    }
    if (i.strapWindow && p.y > 0 && (!lightWindowEligible(i) || !plan.placements.some(b =>
      fitsOnBase(p,b) && ratedGlazingSupport(itemsById.get(b.id))))) {
      issues.push({id:p.id,message:'A strapped window needs a single rated window or door crate or stillage supporting its full footprint.',severity:'error'});
    }
    if(p.en>c.doorWidth||p.yukseklik>c.doorHeight)issues.push({id:p.id,message:'Package cannot pass through the door in this orientation',severity:'error'});
    if(p.x<c.wallGap-1e-9||p.z<c.wallGap-1e-9||p.x+p.en>c.width-c.wallGap+1e-9||p.y+p.yukseklik>c.height-c.wallGap+1e-9||p.z+p.uzunluk>c.length-c.rearReserve+1e-9)issues.push({id:p.id,message:'Inside the reserved wall, roof or door clearance',severity:'error'});
  }
  if(issues.length)return {valid:false,issues};
  const vehicles=plan.containers.map(c=>({...asVehicle(c),yerlesimler:sceneItems(plan,c.id)}));
  const result=denetle(engineInput(plan),vehicles);
  for(const e of result.ihlaller)issues.push({id:e.kalemId,containerId:plan.containers[e.aracIndeksi]?.id,message:ERRORS[e.tur]||'Placement rule violated',severity:e.tur==='teslimatSirasi'?'warning':'error'});
  // Unweighed pieces may not load another package; unknown gross mass is never zero in the UI.
  for(const c of plan.containers){const list=sceneItems(plan,c.id);list.forEach((p,index)=>{if(plan.items.find(i=>i.id===p.id)?.weight===null&&p.y>0)issues.push({id:p.id,message:'Enter a gross weight before stacking this package',severity:'error'});});}
  const groups=new Set(plan.containers.map(c=>c.combinationGroup).filter(Boolean));for(const group of groups){const decks=plan.containers.filter(c=>c.combinationGroup===group),limits=decks.map(c=>c.payload),known=plan.placements.filter(p=>decks.some(c=>c.id===p.containerId)).reduce((n,p)=>n+(plan.items.find(i=>i.id===p.id)?.weight||0),0);if(known>Math.min(...limits))issues.push({containerId:decks[0].id,message:'Combined trailer cargo exceeds the entered combination payload',severity:'error'});}
  return {valid:!issues.some(i=>i.severity==='error'),issues,vehicles:result.araclar};
}
export function orderPlacements(plan){
  const result=validateLayout(plan);
  if(!result.vehicles)return result;
  const positions=new Map(plan.placements.map(p=>[p.id,p]));
  const ordered=[], loaded=new Set();
  const append=p=>{if(p&&!loaded.has(p.id)){ordered.push(p);loaded.add(p.id);}};
  for(const vehicle of result.vehicles)for(const step of vehicle.yerlesimler){
    const p=positions.get(step.kalemId),item=plan.items.find(i=>i.id===p.id);
    if(item.category==='Windows'&&p.y>0){
      for(const id of windowSideSupports(plan,item,p))if(id!=='wall')append(positions.get(id));
    }
    append(p);
  }
  plan.placements=ordered;
  return result;
}
export function supportsAbove(plan,id){const p=plan.placements.find(p=>p.id===id);if(!p)return [];const list=sceneItems(plan,p.containerId);return ustundekiler(list,[list.findIndex(p=>p.id===id)]).map(n=>list[n].id);}
export function unplace(plan,ids){const all=new Set(ids);for(const id of ids)for(const child of supportsAbove(plan,id))all.add(child);plan.placements=plan.placements.filter(p=>!all.has(p.id));return [...all];}
// Resize equipment while retaining valid placements. Cargo that no longer fits stays
// in the shipment manifest and can be placed again; the UI transaction supports undo.
export function updateContainer(plan,cid,changes){
  const c=plan.containers.find(c=>c.id===cid);
  if(!c)throw Error('Container not found');
  if(changes.preset&&changes.preset!==c.preset&&changes.preset!=='custom'){
    if(changes.configuration!=='bdouble')delete c.combinationGroup;
    for(const key of ['gvm','gcm','axles','trailerGvm','body','configuration','vehicleReference'])delete c[key];
  }
  if (['wallGap','length','width','height','type'].some(k=>Object.hasOwn(changes,k)&&changes[k]!==c[k]) ||
      (changes.preset && changes.preset!=='custom' && changes.preset!==c.preset)) delete c.wallBlockingPlanned;
  const {id:ignoredId,...fields}=changes;Object.assign(c,fields);
  // Validate equipment fields before considering the existing layout.
  assertPlan({...plan,placements:[]});
  const removed=[];
  for(let n=0;n<=plan.items.length;n++){
    const check=validateLayout(plan);
    if(check.valid)return removed;
    const ids=[...new Set(check.issues.filter(i=>i.severity==='error'&&i.id&&plan.placements.some(p=>p.id===i.id&&p.containerId===cid)).map(i=>i.id))];
    // Payload violations concern the whole container rather than one package.
    if(!ids.length){
      const candidates=plan.placements.filter(p=>p.containerId===cid);
      if(!candidates.length)throw Error(check.issues.find(i=>i.severity==='error').message);
      ids.push(candidates[candidates.length-1].id);
    }
    removed.push(...unplace(plan,ids));
  }
  throw Error('Could not validate the resized container');
}
export function orientations(i){const pairs=[[i.w,i.h,i.l],[i.l,i.h,i.w]];if(handlingRotation(i)==='fixed')return pairs.slice(0,1);if(handlingRotation(i)==='free')pairs.push([i.h,i.w,i.l],[i.l,i.w,i.h],[i.h,i.l,i.w],[i.w,i.l,i.h]);return pairs.filter((a,n)=>pairs.findIndex(b=>a.join()===b.join())===n);}
function overlap(a, sizeA, b, sizeB) {
  return a < b + sizeB && b < a + sizeA;
}
function directlySupports(base, top) {
  return base.containerId === top.containerId && base.y + base.yukseklik === top.y &&
    overlap(base.x, base.en, top.x, top.en) && overlap(base.z, base.uzunluk, top.z, top.uzunluk);
}
const lateralSupportIssue = 'A stacked window needs protected, independently restrained support on both broad faces at its stacked height.';
const sameFace = (a,b) => Math.abs(a-b)<1e-7;
export function hasContainerWalls(c) {
  return (c.type || PRESETS[c.preset]?.type || 'konteyner')==='konteyner';
}
// Return the two lateral restraints. A package's outer dimensions include its protection.
export function windowSideSupports(plan,item,p) {
  const c=plan.containers.find(v=>v.id===p.containerId);
  const across=sameFace(p.en,item.w);
  const axis=across?'x':'z', width=across?'en':'uzunluk';
  const along=across?'z':'x', length=across?'uzunluk':'en';
  const start=p[axis],end=start+p[width];
  const wall=c && c.wallBlockingPlanned===true && hasContainerWalls(c);
  // Side walls and the fixed nose may count. The rear door never counts.
  let left=wall && sameFace(start,c.wallGap)?'wall':null;
  let right=wall && across && sameFace(end,c.width-c.wallGap)?'wall':null;
  for(const q of plan.placements){
    if(left && right)break;
    if(q.containerId!==p.containerId || q.id===p.id || q.y!==0 ||
      q.y+q.yukseklik<p.y+p.yukseklik || q[along]>p[along] || q[along]+q[length]<p[along]+p[length])continue;
    const atLeft=sameFace(q[axis]+q[width],start),atRight=sameFace(q[axis],end);
    if(!atLeft&&!atRight)continue;
    const other=plan.items.find(i=>i.id===q.id);
    if(!other || other.sideBracePlanned!==true || !['Windows','Doors'].includes(other.category) ||
      !['Wrapped frame','Timber crate','A-frame stillage'].includes(other.packaging) ||
      other.rotation==='free' || !sameFace(q[width],other.w) || other.delivery<item.delivery ||
      (other.specialPacking&&!other.packagingConfirmed))continue;
    if(atLeft)left=q.id;
    if(atRight)right=q.id;
  }
  return [left,right];
}
export function lightWindowEligible(item) {
  return item.category === 'Windows' && Number.isFinite(item.weight) && item.weight > 0 && item.weight <= 50 &&
    item.rotation !== 'free' && (!item.specialPacking || item.packagingConfirmed);
}
function ratedGlazingSupport(item) {
  return item && ['Windows','Doors'].includes(item.category) && ['Timber crate','A-frame stillage'].includes(item.packaging) &&
    item.stackable && Number.isFinite(item.maxTopLoad) && item.maxTopLoad > 0 && (!item.specialPacking || item.packagingConfirmed);
}
function fitsOnBase(p, b) {
  return p.containerId === b.containerId && p.y === b.y + b.yukseklik &&
    p.x >= b.x && p.x+p.en <= b.x+b.en && p.z >= b.z && p.z+p.uzunluk <= b.z+b.uzunluk;
}
export function retainedForOptimise(plan) {
  const locked = new Set(plan.items.filter(i => i.locked).map(i => i.id));
  const keep = new Set(plan.placements.filter(p => locked.has(p.id)));
  // Iterating the Set also visits newly found supports under bridging crates.
  for (const top of keep) {
    const item=plan.items.find(i=>i.id===top.id);
    const sides=item.category==='Windows' && top.y>0 ? windowSideSupports(plan,item,top) : [];
    for (const base of plan.placements) if (directlySupports(base, top) || sides.includes(base.id)) keep.add(base);
  }
  return plan.placements.filter(p => keep.has(p));
}
export function placeOne(plan, id, cid, {respectStops = false, preferWide = false, stackOnly = false, floorFallback = false, edgeStack = false} = {}) {
  const cargo = new Map(plan.items.map(i => [i.id, i]));
  const item = cargo.get(id), c = plan.containers.find(c => c.id === cid);
  if (!item || !c) return false;
  const before = plan.placements;
  const others = before.filter(p => p.id !== id);
  const list = others.filter(p => p.containerId === cid);
  const decks = c.combinationGroup ? plan.containers.filter(d => d.combinationGroup === c.combinationGroup) : [c];
  const deckIds = new Set(decks.map(d => d.id));
  const mass = others.reduce((kg, p) => kg + (deckIds.has(p.containerId) ? cargo.get(p.id).weight || 0 : 0), item.weight || 0);
  if (mass > Math.min(...decks.map(d => d.payload)) + 1e-9) return false;
  const xs = new Set([c.wallGap]), zs = new Set([c.wallGap]), ys = new Set([0]);
  for (const p of list) {
    xs.add(p.x); xs.add(p.x + p.en);
    zs.add(p.z); zs.add(p.z + p.uzunluk);
    if (!item.floorOnly && item.weight !== null && cargo.get(p.id).stackable) ys.add(p.y + p.yukseklik);
  }
  const sort = set => [...set].sort((a,b) => a-b);
  const widths = sort(xs), depths = sort(zs);
  const choices = orientations(item).filter(([w,h,l]) => w <= Math.min(c.doorWidth,c.width-2*c.wallGap) &&
    h <= Math.min(c.doorHeight,c.height-c.wallGap) && l <= c.length-c.wallGap-c.rearReserve);
  if (preferWide) choices.sort((a,b) => b[0]-a[0]);
  if (!floorFallback && item.strapWindow && !item.floorOnly && lightWindowEligible(item)) {
    const bases = list.filter(b => ratedGlazingSupport(cargo.get(b.id)) && cargo.get(b.id).maxTopLoad >= item.weight)
      .sort((a,b)=>a.y+a.yukseklik-b.y-b.yukseklik || a.z-b.z);
    for (const b of bases) for (const [en,yukseklik,uzunluk] of choices) {
      const y=b.y+b.yukseklik;
      if (en>b.en || uzunluk>b.uzunluk || y+yukseklik>c.height-c.wallGap) continue;
      // Try the centre first, then exposed edges when another window shares the base.
      const occupied=list.filter(q=>q.y===y && overlap(b.x,b.en,q.x,q.en) && overlap(b.z,b.uzunluk,q.z,q.uzunluk));
      const firstX=edgeStack?b.x:b.x+(b.en-en)/2, firstZ=edgeStack?b.z:b.z+(b.uzunluk-uzunluk)/2;
      const across=new Set([firstX,b.x,b.x+b.en-en,...occupied.flatMap(q=>[q.x+q.en,q.x-en])]);
      const along=new Set([firstZ,b.z,b.z+b.uzunluk-uzunluk,...occupied.flatMap(q=>[q.z+q.uzunluk,q.z-uzunluk])]);
      for (const z of along) for (const x of across) {
        const top={id,containerId:cid,x,y,z,en,yukseklik,uzunluk};
        if (!fitsOnBase(top,b) || !windowSideSupports(plan,item,top).every(Boolean) || occupied.some(q=>overlap(x,en,q.x,q.en)&&overlap(z,uzunluk,q.z,q.uzunluk))) continue;
        const placements=[...others,top], check=validateLayout({...plan,placements});
        if (!check.valid || (respectStops && check.issues.some(issue=>issue.severity==='warning'))) continue;
        plan.placements=placements;
        return true;
      }
    }
  }
  if (stackOnly) return false;
  if (item.strapWindow) {ys.clear();ys.add(0);}
  let attempts = 0;
  for (const y of sort(ys)) for (const z of depths) for (const x of widths) for (const [en,yukseklik,uzunluk] of choices) {
    if (++attempts > 25000) return false;
    if (x+en > c.width-c.wallGap || y+yukseklik > c.height-c.wallGap || z+uzunluk > c.length-c.rearReserve) continue;
    const candidate = {id,containerId:cid,x,y,z,en,yukseklik,uzunluk};
    let needsStackCheck = y > 0 || others.length !== before.length, blocked = false;
    for (const q of list) {
      if (!overlap(x,en,q.x,q.en)) continue;
      const sameDepth = overlap(z,uzunluk,q.z,q.uzunluk);
      const sameHeight = overlap(y,yukseklik,q.y,q.yukseklik);
      if (sameDepth && sameHeight) { blocked = true; break; }
      if (sameDepth && q.y >= y+yukseklik) needsStackCheck = true;
      if (respectStops) {
        const stop = cargo.get(q.id).delivery;
        if ((sameHeight && ((stop > item.delivery && q.z >= z+uzunluk) || (stop < item.delivery && z >= q.z+q.uzunluk))) ||
            (sameDepth && ((stop < item.delivery && y >= q.y+q.yukseklik) || (stop > item.delivery && q.y >= y+yukseklik)))) {
          blocked = true; break;
        }
      }
    }
    if (blocked) continue;
    if (item.category==='Windows' && y>0 && !windowSideSupports(plan,item,candidate).every(Boolean)) continue;
    const placements = [...others, candidate];
    if (needsStackCheck && !validateLayout({...plan,placements}).valid) continue;
    plan.placements = placements;
    return true;
  }
  return false;
}
export function applyEngine(plan,result){
  const placed=[];const used=new Set();
  for(const a of result.araclar){const c=plan.containers.find(c=>c.id===a.ad&&!used.has(c.id));if(!c)throw Error('Packing engine returned an unknown container');used.add(c.id);for(const p of a.yerlesimler)placed.push({id:p.kalemId,containerId:c.id,x:p.x+c.wallGap,y:p.y,z:p.z+c.wallGap,en:p.en,yukseklik:p.yukseklik,uzunluk:p.uzunluk});}
  const next={...plan,placements:placed};const check=validateLayout(next);if(!check.valid)throw Error(check.issues.find(i=>i.severity==='error').message);plan.placements=placed;orderPlacements(plan);return plan;
}
export function metrics(plan,cid){const c=plan.containers.find(c=>c.id===cid),ps=plan.placements.filter(p=>p.containerId===cid),items=ps.map(p=>plan.items.find(i=>i.id===p.id));const known=items.reduce((t,i)=>t+(i.weight??0),0),unknown=items.filter(i=>i.weight===null).length,volume=ps.reduce((t,p)=>t+p.en*p.yukseklik*p.uzunluk/1e9,0),floor=ps.filter(p=>p.y===0).reduce((t,p)=>t+p.en*p.uzunluk,0);let cog=null;if(known>0&&!unknown)cog=ps.reduce((m,p)=>{const w=plan.items.find(i=>i.id===p.id).weight;return {x:m.x+(p.x+p.en/2)*w/known,y:m.y+(p.y+p.yukseklik/2)*w/known,z:m.z+(p.z+p.uzunluk/2)*w/known};},{x:0,y:0,z:0});return {count:ps.length,total:plan.items.length,volume,capacity:c.width*c.height*c.length/1e9,floorPct:floor/(c.width*c.length)*100,known,unknown,cog,clearance:c.length-Math.max(0,...ps.map(p=>p.z+p.uzunluk))};}
export function clearances(plan,cid,ids=[]){const c=plan.containers.find(c=>c.id===cid),list=sceneItems(plan,cid);return kalanBosluk(asVehicle(c),list,list.map((p,n)=>ids.includes(p.id)?n:-1).filter(n=>n>=0));}
export function groupedCrate(items,label='Window crate',packaging='Timber crate'){
  if(!items.length)throw Error('Select packages first');
  const l=Math.max(...items.map(i=>i.l))+100,w=items.reduce((s,i)=>s+i.w,0)+Math.max(0,items.length-1)*25+100,h=Math.max(...items.map(i=>i.h))+100;
  return newItem({label,category:items.every(i=>i.category===items[0].category)?items[0].category:'Custom cargo',packaging,l,w,h,tare:0,weight:null,weightSource:'Unknown',supplier:[...new Set(items.map(i=>i.supplier).filter(Boolean))].join(', '),consignment:[...new Set(items.map(i=>i.consignment))].join(' + '),contents:clone(items),sources:items.flatMap(i=>i.sources||[]),notes:'Outer dimensions include 50 mm each side and 25 mm between contents. Confirm actual crated dimensions and enter tare.'});
}
export function syncSchedule(plan,rows){
  const existing=new Set(plan.items.flatMap(i=>i.sources||[]));let added=0,changed=0;
  for(const r of rows){if(!(r.l>0&&r.w>0&&r.h>0))continue;for(let n=1;n<=Math.min(300,Math.max(1,r.qty||1));n++){
    const source=r.key+'#'+n;if(existing.has(source)){const item=plan.items.find(i=>i.sources?.includes(source));const linked=i=>i.sourceSize?i:(i.contents||[]).map(linked).find(c=>c?.sources?.includes(source));const child=item&&linked(item);if(child?.sourceSize&&child.sourceSize!==[r.l,r.w,r.h].join('x')){item.scheduleChanged=true;child.scheduleChanged=true;changed++;}continue;}
    if(plan.items.length>=300)break;plan.items.push(newItem({...r,id:uid(),label:r.label+(r.qty>1?' #'+n:''),sources:[source],sourceKey:r.key,sourceSize:[r.l,r.w,r.h].join('x'),packaging:r.packaging||'Wrapped frame',category:r.category||'Windows',rotation:r.rotation||'upright',floorOnly:true}));existing.add(source);added++;
  }}return {added,changed};
}
export function validateLabelBranding(raw=[]){
 if(!Array.isArray(raw)||raw.length>20)throw Error('Use no more than 20 supplier label profiles.');
 const suppliers=new Set();
 return raw.map(b=>{
  if(!b||typeof b!=='object')throw Error('Invalid supplier label profile');
  const supplier=String(b.supplier??'').trim().slice(0,200),name=String(b.name??'').trim().slice(0,200),logo=String(b.logo??'');
  if(suppliers.has(supplier))throw Error('Duplicate supplier label profile');suppliers.add(supplier);
  if(logo&&(logo.length>200000||!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(logo)))throw Error('Use a PNG, JPG or WebP logo under 150 KB after resizing.');
  return {supplier,name,logo};
 });
}
const vehicleFactNames=['gvm','gcm','axles','trailerGvm'];
export function vehicleFactValue(key,raw){
 if(typeof raw!=='number'&&(typeof raw!=='string'||!raw.trim()))return null;
 const value=Number(raw);
 if(!Number.isFinite(value)||value<1||value>200000)return null;
 return key!=='axles'||(Number.isInteger(value)&&value>=2&&value<=12)?value:null;
}
export function updateVehicleFact(plan,id,key,raw){
 if(!vehicleFactNames.includes(key))throw Error('Unknown vehicle rating');
 const vehicle=plan.containers.find(c=>c.id===id);
 if(!vehicle)throw Error('Vehicle not found');
 const value=vehicleFactValue(key,raw);
 if(raw!=null&&raw!==''&&value===null)throw Error(key==='axles'?'Enter a whole axle count from 2 to 12.':'Enter a mass from 1 to 200,000 kg.');
 vehicle[key]=value;
 if(vehicle.combinationGroup&&key!=='trailerGvm'){
  for(const other of plan.containers.filter(c=>c.combinationGroup===vehicle.combinationGroup))other[key]=value;
 }
}
export function useBdouble(plan,active,{lengthA=7800,lengthB=12600,width=2400,height=2700,payload=22000,gvm=null,gcm=null,axles=null}={}){
 const current=plan.containers.find(c=>c.id===active);if(!current)throw Error('Vehicle not found');
 const partner=current.combinationGroup?plan.containers.find(c=>c.id!==active&&c.combinationGroup===current.combinationGroup):null;
 if(!partner&&plan.containers.length>=20)throw Error('A B-double needs two trailer spaces; remove a vehicle first.');
 const group=current.combinationGroup||uid(),spec=PRESETS['fleet-bdouble'],common={...spec,width,height,doorWidth:width,doorHeight:height,payload,gvm,gcm,axles,trailerGvm:null,preset:'fleet-bdouble'};
 // Resize each deck independently before enforcing the combination's shared limit.
 delete current.combinationGroup;if(partner)delete partner.combinationGroup;
 const removed=updateContainer(plan,active,{...common,length:lengthA,name:'B-double · Trailer A'});
 const second=partner||newContainer('fleet-bdouble');if(!partner)plan.containers.push(second);
 removed.push(...updateContainer(plan,second.id,{...common,length:lengthB,type:'romork',name:'B-double · Trailer B'}));
 current.combinationGroup=second.combinationGroup=group;
 while(!validateLayout(plan).valid){const last=plan.placements.findLast(p=>p.containerId===active||p.containerId===second.id);if(!last)throw Error('Could not validate B-double');removed.push(...unplace(plan,[last.id]));}
 return removed;
}
export function loadingSignature(item,position,plan){const sides=plan && item.category==='Windows' && position.y>0 ? windowSideSupports(plan,item,position) : [];return JSON.stringify([position.containerId,position.x,position.y,position.z,position.en,position.yukseklik,position.uzunluk,item.weight,...(item.strapWindow&&position.y>0?['strap']:[]),...sides]);}
export function removeVehicles(plan,vehicleIds){const ids=new Set(vehicleIds);if(!ids.size||[...ids].some(id=>!plan.containers.some(c=>c.id===id)))throw Error('Choose existing vehicles.');if(ids.size>=plan.containers.length)throw Error('Keep at least one vehicle; clear its cargo instead.');const affected=plan.placements.filter(p=>ids.has(p.containerId)).map(p=>p.id);plan.placements=plan.placements.filter(p=>!ids.has(p.containerId));plan.containers=plan.containers.filter(c=>!ids.has(c.id));for(const id of affected)if(plan.loadingChecks)delete plan.loadingChecks[id];return affected;}
export function assertPlan(raw){
  if(!raw||raw.schema!==SCHEMA||!Array.isArray(raw.items)||raw.items.length>300||!Array.isArray(raw.containers)||raw.containers.length<1||raw.containers.length>20||!Array.isArray(raw.placements)||raw.placements.length>300)throw Error('Not a valid WinMatch cargo plan (maximum 300 packages / 20 containers).');
  const ids=new Set();const text=(x,max=4000)=>String(x??'').slice(0,max);const number=(n,min,max,name)=>{if(typeof n!=='number'||!Number.isFinite(n)||n<min||n>max)throw Error('Invalid '+name);return n;};
  const items=(list,depth=0)=>{if(depth>5||list.length>300)throw Error('Invalid nested contents');return list.map(i=>{if(!i.id||ids.has(i.id))throw Error('Duplicate package ID');ids.add(i.id);let o=newItem({...i});for(const k of ['label','supplier','consignment','room','notes','weightSource','id'])o[k]=text(i[k]);if(!o.label)o.label='Package';if(!CATEGORIES[o.category])o.category='Custom cargo';if(!['Loose','Wrapped frame','Timber crate','A-frame stillage','Pallet','Carton','Bundle'].includes(o.packaging))o.packaging='Carton';for(const k of ['l','w','h'])o[k]=number(i[k],1,30000,k);o.weight=i.weight===null?null:number(i.weight,0,200000,'weight');o.maxTopLoad=i.maxTopLoad==null?null:number(i.maxTopLoad,0,200000,'top load');o.tare=number(i.tare??0,0,200000,'tare');o.delivery=Math.round(number(i.delivery??1,1,999,'delivery'));o.rotation=handlingRotation(o);for(const k of ['stackable','floorOnly','locked'])o[k]=!!i[k];o.contents=items(Array.isArray(i.contents)?i.contents:[],depth+1);o.sources=Array.isArray(i.sources)?i.sources.slice(0,300).map(x=>text(x,150)):[];return o;});};
  const out={schema:SCHEMA,ref:text(raw.ref,200),notes:text(raw.notes,20000),labelBranding:validateLabelBranding(raw.labelBranding),items:items(raw.items),containers:raw.containers.map(c=>{if(!c.id||ids.has(c.id))throw Error('Duplicate container ID');ids.add(c.id);const o={id:text(c.id),preset:text(c.preset),name:text(c.name,100),type:['konteyner','kamyonet','kamyon','tir','romork'].includes(c.type)?c.type:(PRESETS[c.preset]?.type||'konteyner')};for(const k of ['length','width','height','doorWidth','doorHeight'])o[k]=Math.round(number(c[k],200,30000,k));o.payload=number(c.payload,1,200000,'payload');o.wallGap=number(c.wallGap,0,500,'wall clearance');o.rearReserve=number(c.rearReserve,0,5000,'door reserve');if(o.width<=2*o.wallGap||o.height<=o.wallGap||o.length<=o.wallGap+o.rearReserve)throw Error('Clearances leave no usable space');return o;}),placements:raw.placements.map(p=>{const o={id:text(p.id),containerId:text(p.containerId)};for(const k of ['x','y','z','en','yukseklik','uzunluk'])o[k]=number(p[k],0,30000,k);return o;}),updatedAt:text(raw.updatedAt)};
  for(let n=0;n<out.containers.length;n++){
    const c=out.containers[n],r=raw.containers[n];
    if(r.wallBlockingPlanned===true)c.wallBlockingPlanned=true;
    for(const key of vehicleFactNames)if(Object.hasOwn(r,key))c[key]=vehicleFactValue(key,r[key]);
    for(const key of ['body','configuration','combinationGroup'])if(typeof r[key]==='string')c[key]=text(r[key],100);
    const reference=r.vehicleReference||r.preset;
    if(Object.hasOwn(TRUCK_PRESETS,reference))c.vehicleReference=reference;
  }
  if(raw.loadingChecks&&typeof raw.loadingChecks==='object'&&!Array.isArray(raw.loadingChecks)){out.loadingChecks={};for(const pos of out.placements){const i=out.items.find(i=>i.id===pos.id);if(i&&raw.loadingChecks[pos.id]===loadingSignature(i,pos,out))out.loadingChecks[pos.id]=raw.loadingChecks[pos.id];}}
  if(raw.truckDelivery!=null){if(typeof raw.truckDelivery!=='object'||!Array.isArray(raw.truckDelivery.packs)||raw.truckDelivery.packs.length>500||JSON.stringify(raw.truckDelivery).length>1000000)throw Error('Invalid truck delivery draft');const td=raw.truckDelivery;for(const p of td.packs){if(!p.id||!p.label||!['A','B'].includes(p.site)||!['estimated','confirmed'].includes(p.status)||!['crate','pack','item'].includes(p.kind)||!['intact','loose'].includes(p.delivery)||!['l','w','h','kg','qty'].every(k=>Number.isFinite(+p[k])&&+p[k]>0)||!Number.isInteger(+p.qty)||+p.qty>1000)throw Error('Invalid truck delivery packing');if(p.delivery==='loose'&&(!['looseL','looseW','looseH','looseKg','looseQty'].every(k=>Number.isFinite(+p[k])&&+p[k]>0)||!Number.isInteger(+p.looseQty)||+p.looseQty>1000))throw Error('Invalid loose-delivery packing');}out.truckDelivery=clone(td);}
  // Earlier plan files can mark glazing as freely rotatable, including lying on its side.
  // Preserve upright placements and return tipped packages and their supported cargo to the manifest.
  const tipped=out.placements.filter(p=>{
    const item=out.items.find(i=>i.id===p.id);
    return item && ['Windows','Doors'].includes(item.category) && p.yukseklik!==item.h && p.yukseklik!==Math.round(item.h);
  }).map(p=>p.id);
  if(tipped.length) for(const id of unplace(out,tipped)) if(out.loadingChecks) delete out.loadingChecks[id];
  const corrected = [];
  for (const p of out.placements) {
    const item = out.items.find(i => i.id === p.id);
    if (!item) continue;
    const dims = [p.en,p.yukseklik,p.uzunluk], choices = orientations(item);
    if (choices.some(a => a.every((v,k) => v === dims[k]))) continue;
    const original = choices.find(a => a.every((v,k) => Math.round(v) === dims[k]));
    if (original) {
      corrected.push(p.id);
      [p.en,p.yukseklik,p.uzunluk] = original;
      if (out.loadingChecks) delete out.loadingChecks[p.id];
    }
  }
  if (corrected.length && !validateLayout(out).valid) {
    unplace(out,corrected);
    // Old rounded stack heights may have left a piece just above its support.
    for (let pass=0;pass<out.items.length;pass++) {
      const unsupported=validateLayout(out).issues.filter(e=>e.message===ERRORS.destek).map(e=>e.id);
      if (!unsupported.length) break;
      unplace(out,unsupported);
    }
  }
  const unsupported=validateLayout(out).issues.filter(e=>e.code==='window-side-support').map(e=>e.id);
  if(unsupported.length){
    const affected=unplace(out,unsupported);
    for(const item of out.items.filter(i=>affected.includes(i.id))){
      item.sideSupportReview=true;
      if(out.loadingChecks)delete out.loadingChecks[item.id];
    }
  }
  const v=validateLayout(out);if(!v.valid)throw Error('Plan has an invalid layout: '+v.issues[0].message);return out;
}
export function samplePlan(){const p=blankPlan();p.ref='Whole-of-home · Coastal Pavilion';const data=[
  ['W01–W04','Windows','A-frame stillage',2450,650,1950,420,'Glazing supplier','Living & bedrooms'],
  ['D01 Sliding door','Doors','Timber crate',2900,400,2450,285,'Glazing supplier','Living'],
  ['CAB-01 Kitchen','Cabinetry','Timber crate',2200,1000,1100,380,'Joinery supplier','Kitchen'],
  ['CAB-02 Vanities','Cabinetry','Carton',1200,700,900,95,'Joinery supplier','Bathrooms'],
  ['STN-01 Benchtops','Benchtops','A-frame stillage',3000,700,1300,720,'Stone supplier','Kitchen'],
  ['TIL-01 Floor tiles','Tiles & stone','Pallet',1200,1000,800,950,'Tile supplier','Ground floor'],
  ['TIL-02 Wall tiles','Tiles & stone','Pallet',1200,800,650,620,'Tile supplier','Bathrooms'],
  ['ELE-01 Lighting','Electrical','Carton',800,600,600,32,'Electrical supplier','Whole home'],
  ['CUR-01 Curtains','Curtains & blinds','Carton',1600,500,500,45,'Furnishings supplier','Bedrooms'],
  ['PLB-01 Fixtures','Plumbing','Carton',900,650,750,65,'Bathroom supplier','Bathrooms']
];p.items=data.map(([label,category,packaging,l,w,h,weight,supplier,room])=>newItem({label,category,packaging,l,w,h,weight,supplier,room,weightSource:'Sample',stackable:category==='Tiles & stone',maxTopLoad:category==='Tiles & stone'?1000:null,notes:category==='Windows'?'Contents: W01, W02, W03, W04':''}));return p;}
