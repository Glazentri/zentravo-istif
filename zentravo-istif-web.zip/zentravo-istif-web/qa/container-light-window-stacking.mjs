import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import * as C from '../public/container-studio/core.js';

let reply;
const worker=vm.createContext({self:{},performance,postMessage:m=>{if(m.plan||m.error)reply=m;}});
vm.runInContext(readFileSync('public/container-studio/worker.bundle.txt','utf8'),worker);
const base=()=>C.newItem({category:'Windows',packaging:'Timber crate',label:'W01',rotation:'fixed',w:250,l:2400,h:1400,weight:200,maxTopLoad:70,stackable:true});
const small=()=>C.newItem({category:'Windows',label:'W02',rotation:'fixed',w:250,l:1000,h:750,weight:50,strapWindow:true,floorOnly:false});
const brace=()=>C.newItem({category:'Windows',label:'W03',packaging:'Timber crate',rotation:'fixed',w:200,l:2400,h:2250,weight:140,sideBracePlanned:true});
function plan(){
  const p={...C.blankPlan(),items:[small(),base(),brace()]};
  p.containers[0].wallBlockingPlanned=true;
  return p;
}
function pack(p,mode='optimise'){
  reply=null;worker.self.onmessage({data:{plan:structuredClone(p),mode}});
  assert.ok(reply?.plan,reply?.error);const packed=structuredClone(reply.plan);
  assert.ok(C.validateLayout(packed).valid);return packed;
}
function height(p){return p.placements.find(q=>q.id===p.items[0].id)?.y;}
const initial=pack(plan());assert.equal(height(initial),1400);
const upper=initial.placements.find(q=>q.id===initial.items[0].id),lower=initial.placements.find(q=>q.id===initial.items[1].id);
assert.equal(upper.x+upper.en/2,lower.x+lower.en/2);assert.equal(upper.z+upper.uzunluk/2,lower.z+lower.uzunluk/2);
assert.equal(C.assertPlan(JSON.parse(JSON.stringify(initial))).items[0].strapWindow,true);
for(const kg of [49.99,50,50.01,0,null]){
  const p=plan();p.items[0].weight=kg;
  assert.equal(height(pack(p)),kg>0&&kg<=50?1400:0);
}
for(const patch of [{maxTopLoad:49.99},{stackable:false},{packaging:'Wrapped frame'},{w:200},{h:2200},{category:'Cabinetry'},{specialPacking:true,packagingConfirmed:false}]){
  const p=plan();Object.assign(p.items[1],patch);assert.equal(height(pack(p)),0,JSON.stringify(patch));
}
let p=plan();p.items.push(small());const multiple=pack(p);
assert.equal(multiple.placements.filter(q=>q.y>0).length,1,'combined upper weight exceeds 70 kg rating');
p=plan();p.items[1].category='Doors';assert.equal(height(pack(p)),1400);
p=plan();p.items[0].floorOnly=true;assert.equal(height(pack(p)),0);
p=plan();p.items[0].delivery=2;p.items[1].delivery=1;assert.equal(height(pack(p)),0);
p=plan();p.containers.push(C.newContainer('40hc',2));
p.containers[1].wallBlockingPlanned=true;C.placeOne(p,p.items[1].id,p.containers[1].id);C.placeOne(p,p.items[2].id,p.containers[1].id);
assert.equal(height(pack(p,'pack')),1400,'use rated base in second vehicle before empty floor in first');
const restored=C.clone(initial);restored.items[0].weight=50.01;
assert.equal(C.validateLayout(restored).valid,false,'manual and imported layouts obey the upper weight limit');
restored.items[0].weight=50;restored.placements.find(q=>q.id===restored.items[0].id).x=lower.x-1;
assert.equal(C.validateLayout(restored).valid,false,'manual overhang rejected');
// The independent brace must already be in position when the top window is loaded.
assert.ok(initial.placements.findIndex(q=>q.id===initial.items[2].id)<initial.placements.findIndex(q=>q.id===initial.items[0].id));
const upperItem=initial.items[0];
assert.deepEqual(C.windowSideSupports(initial,upperItem,upper),['wall',initial.items[2].id]);
for(const reason of ['one side only','short neighbour','narrow contact','one mm gap','unrestrained','loose glass','unblocked wall','truck wall','earlier unload','end contact']){
 const d=C.clone(initial), side=d.placements.find(q=>q.id===d.items[2].id), win=d.placements.find(q=>q.id===d.items[0].id);
 if(reason==='one side only')d.placements=d.placements.filter(q=>q!==side);
 if(reason==='short neighbour')side.yukseklik=win.y+win.yukseklik-1;
 if(reason==='narrow contact'){side.z=win.z+1;}
 if(reason==='one mm gap')side.x++;
 if(reason==='unrestrained')d.items[2].sideBracePlanned=false;
 if(reason==='loose glass')d.items[2].packaging='Loose';
 if(reason==='unblocked wall')d.containers[0].wallBlockingPlanned=false;
 if(reason==='truck wall')d.containers[0].type='kamyon';
 if(reason==='earlier unload')d.items[0].delivery=2;
 if(reason==='end contact')d.items[2].w=side.uzunluk;
 assert.ok(C.validateLayout(d).issues.some(e=>e.code==='window-side-support'),reason);
}
const two=C.clone(initial), c=two.containers[0], left=brace();c.wallBlockingPlanned=false;
for(const q of two.placements)q.x+=left.w;
const right=two.placements.find(q=>q.id===two.items[2].id);
two.items.push(left);two.placements.push({...right,id:left.id,x:c.wallGap});
assert.ok(C.validateLayout(two).valid,'two independent packages on opposite sides');
const legacy=C.clone(initial);delete legacy.containers[0].wallBlockingPlanned;
const migrated=C.assertPlan(legacy);assert.equal(migrated.items.length,3);assert.equal(migrated.placements.length,2);assert.ok(migrated.items[0].sideSupportReview);
// Rotating all packages swaps broad face axes. A blocked nose can support a face, a rear door cannot.
const rot=C.clone(initial);rot.items.forEach(i=>{i.rotation='upright';});rot.containers[0].width=3000;rot.containers[0].doorWidth=2900;
for(const q of rot.placements){[q.x,q.z]=[q.z,q.x];[q.en,q.uzunluk]=[q.uzunluk,q.en];}
assert.ok(C.validateLayout(rot).valid);
const rTop=rot.placements.find(q=>q.id===rot.items[0].id);rTop.z=rot.containers[0].length-rTop.uzunluk-rot.containers[0].rearReserve;
assert.ok(!C.windowSideSupports(rot,rot.items[0],rTop)[1]);
console.log('Light window stacking and two-sided support checks passed');
