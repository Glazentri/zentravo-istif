import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import * as C from '../public/container-studio/core.js';

let reply;
const worker=vm.createContext({self:{},performance,structuredClone,postMessage:msg=>{if(msg.plan||msg.error)reply=msg;}});
vm.runInContext(readFileSync(new URL('../public/container-studio/worker.bundle.txt',import.meta.url),'utf8'),worker);
const box=options=>C.newItem({rotation:'fixed',weight:10,...options});
function make(width,length,height,items,options={}) {
  const p=C.blankPlan();
  Object.assign(p.containers[0],{width:width+40,length:length+170,height:height+20,doorWidth:width,doorHeight:height,...options});
  p.items=items;
  return p;
}
function pack(plan,mode='pack') {
  reply=null;
  worker.self.onmessage({data:{plan:structuredClone(plan),mode}});
  assert.ok(reply?.plan,reply?.error);
  const packed=structuredClone(reply.plan);
  assert.deepEqual(packed.items,plan.items);
  assert.ok(C.validateLayout(packed).valid);
  return packed;
}
const at=(i,c,x,y,z)=>({id:i.id,containerId:c.id,x:x+20,y,z:z+20,en:i.w,yukseklik:i.h,uzunluk:i.l});
for(const category of ['Windows','Doors']){
  const tall=box({category,rotation:'free',w:300,h:1600,l:1000,stackable:true,maxTopLoad:60});
  const child=box({w:200,l:500,h:300,floorOnly:false});
  const p=make(1200,2400,1200,[tall,child]),c=p.containers[0];
  const tipped={...at(tall,c,0,0,0),en:1000,yukseklik:300,uzunluk:1600};
  p.placements=[tipped,at(child,c,0,300,0)];
  p.loadingChecks={[tall.id]:'old pick',[child.id]:'old pick'};
  const migrated=C.assertPlan(p);
  assert.equal(migrated.items[0].rotation,'upright');
  assert.equal(migrated.placements.length,0);
  assert.equal(migrated.items.length,2);
  assert.ok(!Object.keys(migrated.loadingChecks??{}).length);
  assert.ok(pack(migrated).placements.every(a=>a.id!==tall.id));
  p.placements=[];p.containers[0].height=1800;p.containers[0].doorHeight=1700;
  const recovered=pack(C.assertPlan(p)).placements.find(a=>a.id===tall.id);
  assert.equal(recovered.yukseklik,1600);
}
// Two small windows fit end-to-end with no free floor. Centring the first would strand the second.
const base=box({category:'Doors',w:220,l:1600,h:1100,weight:150,packaging:'Timber crate',stackable:true,maxTopLoad:81});
const brace=box({category:'Windows',w:180,l:1600,h:2000,weight:140,packaging:'Timber crate',sideBracePlanned:true});
const top=()=>box({category:'Windows',w:220,l:800,h:850,weight:30,floorOnly:false,strapWindow:true});
const windows=pack(make(400,1600,2000,[base,brace,top(),top()],{wallBlockingPlanned:true}));
assert.equal(windows.placements.length,4);
const uppers=windows.placements.filter(a=>a.y>0);
assert.deepEqual(uppers.map(a=>a.z).sort((a,b)=>a-b),[20,820]);
for(const a of uppers)assert.deepEqual(C.windowSideSupports(windows,windows.items.find(i=>i.id===a.id),a),['wall',brace.id]);

// The maximum count under a shared 100 kg payload is five light packages.
const heavy=box({w:1000,l:1000,h:300,weight:100});
const mixed=make(1000,9000,400,[heavy,...Array.from({length:10},()=>box({w:500,l:900,h:400,weight:20}))],{payload:100,combinationGroup:'two-decks'});
mixed.containers.push({...mixed.containers[0],id:'second'});
const best=pack(mixed);
assert.equal(best.placements.length,5);
assert.ok(best.placements.every(a=>a.id!==heavy.id));

// An explicit cut-tree witness tiles a 12 by 10 floor. The first tile is locked off the wall.
const witness=[[10,8,1,2],[7,1,2,2],[0,7,10,3],[3,0,1,1],[4,0,8,1],[0,3,10,2],[9,1,1,2],
  [0,5,10,2],[10,1,1,7],[0,0,3,1],[0,1,7,2],[11,1,1,5],[11,6,1,4]];
const p=make(1200,1000,800,witness.map(([x,z,w,l])=>box({w:w*100,l:l*100,h:800})));
p.placements=witness.map(([x,z],i)=>at(p.items[i],p.containers[0],x*100,0,z*100));
assert.ok(C.validateLayout(p).valid);
p.placements=p.placements.slice(0,1);p.items[0].locked=true;
const tiled=pack(p,'optimise');
assert.equal(tiled.placements.length,13);
assert.deepEqual(tiled.placements.find(a=>a.id===p.items[0].id),p.placements[0]);
console.log('Imported glazing, paired braced windows, shared payload and locked floor tiling passed.');
