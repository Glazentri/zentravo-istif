import assert from 'node:assert/strict';
import * as C from '../public/container-studio/core.js';
import {planla} from '../public/container-studio/vendor/istif/js/motor/motor.js';
const passed=[];
function test(name,fn){fn();passed.push(name);}
const box=opts=>C.newItem({l:1000,w:800,h:600,weight:100,...opts});
const at=(i,c,x=20,y=0,z=20)=>({id:i.id,containerId:c.id,x,y,z,en:i.w,yukseklik:i.h,uzunluk:i.l});
test('Whole-home mixed cargo packs and round-trips without loss',()=>{const p=C.samplePlan();C.applyEngine(p,planla(C.engineInput(p,true)));assert.equal(p.placements.length,10);assert.equal(C.validateLayout(p).valid,true);assert.equal(C.assertPlan(JSON.parse(JSON.stringify(p))).items.length,10);assert.equal(C.metrics(p,p.containers[0].id).known,3612);});
test('Collisions, negative coordinates and door reserve are rejected',()=>{const p=C.blankPlan(),c=p.containers[0],a=box(),b=box();p.items=[a,b];p.placements=[at(a,c),at(b,c)];assert.equal(C.validateLayout(p).valid,false);p.placements.pop();p.placements[0].x=-1;assert.equal(C.validateLayout(p).valid,false);p.placements[0]=at(a,c,20,0,c.length-c.rearReserve-900);assert.equal(C.validateLayout(p).valid,false);});
test('Upright door height is enforced by the engine and manual validator',()=>{const p=C.blankPlan(),c=p.containers[0];c.doorHeight=2200;const a=box({h:2400,rotation:'upright'});p.items=[a];C.applyEngine(p,planla(C.engineInput(p,true)));assert.equal(p.placements.length,0);p.placements=[at(a,c)];assert.equal(C.validateLayout(p).valid,false);});
test('No invented weight and no centre of gravity with missing weights',()=>{const p=C.blankPlan(),a=box({weight:null});p.items=[a];p.placements=[at(a,p.containers[0])];const m=C.metrics(p,p.containers[0].id);assert.equal(m.known,0);assert.equal(m.unknown,1);assert.equal(m.cog,null);});
test('Rated stacking, support and cumulative loads are enforced',()=>{const p=C.blankPlan(),c=p.containers[0],a=box({stackable:true,maxTopLoad:150}),b=box({floorOnly:false,weight:100});p.items=[a,b];p.placements=[at(a,c),at(b,c,20,600)];assert.equal(C.validateLayout(p).valid,true);a.maxTopLoad=50;assert.equal(C.validateLayout(p).valid,false);a.maxTopLoad=150;p.placements[1].x=100;assert.equal(C.validateLayout(p).valid,false);p.placements[1].x=20;p.placements[1].y=601;assert.equal(C.validateLayout(p).valid,false);});
test('Crates retain contents and schedule sync never duplicates them',()=>{const p=C.blankPlan(),rows=[{key:'w1',label:'W01',l:1800,w:200,h:1500,qty:2,weight:65,category:'Windows'}];assert.equal(C.syncSchedule(p,rows).added,2);const crate=C.groupedCrate(p.items);assert.equal(crate.contents.length,2);assert.equal(crate.weight,null);assert.equal(crate.w,525);p.items=[crate];assert.equal(C.syncSchedule(p,rows).added,0);assert.equal(p.items.length,1);assert.equal(C.assertPlan(p).items[0].contents.length,2);rows[0].l=1900;assert.equal(C.syncSchedule(p,rows).changed,2);assert.equal(crate.scheduleChanged,true);assert.equal(crate.contents[1].scheduleChanged,true);});
test('Schedule changes flag packages without moving or overwriting them',()=>{const p=C.blankPlan(),rows=[{key:'w1',label:'W01',l:1800,w:200,h:1500,weight:65}];C.syncSchedule(p,rows);C.placeOne(p,p.items[0].id,p.containers[0].id);const before=JSON.stringify(p.placements);rows[0].l=1900;assert.equal(C.syncSchedule(p,rows).changed,1);assert.equal(p.items[0].l,1800);assert.equal(JSON.stringify(p.placements),before);});
test('Adding cargo preserves all manual placements',()=>{const p=C.blankPlan(),c=p.containers[0],a=box(),b=box();p.items=[a,b];p.placements=[at(a,c,100,0,3000)];const before=JSON.stringify(p.placements[0]);assert.equal(C.placeOne(p,b.id,c.id),true);assert.equal(JSON.stringify(p.placements[0]),before);});
test('Unplacing a supporting package also unplaces its stack',()=>{const p=C.blankPlan(),c=p.containers[0],a=box({stackable:true,maxTopLoad:200}),b=box({floorOnly:false});p.items=[a,b];p.placements=[at(a,c),at(b,c,20,600)];assert.deepEqual(C.supportsAbove(p,a.id),[b.id]);C.unplace(p,[a.id]);assert.equal(p.placements.length,0);});
test('Mixed container types use their own dimensions and ids',()=>{const p=C.blankPlan();p.containers=[C.newContainer('20gp'),C.newContainer('40hc',2)];p.items=Array.from({length:6},()=>box({l:3000,w:2000,h:2000}));C.applyEngine(p,planla(C.engineInput(p,true)));assert.equal(C.validateLayout(p).valid,true);assert.equal(new Set(p.placements.map(p=>p.containerId)).size,2);});
test('Fractional millimetre placements survive a saved-plan round trip',()=>{const p=C.blankPlan(),i=box();p.items=[i];p.placements=[at(i,p.containers[0],100.5,0,3000.5)];assert.deepEqual(C.assertPlan(JSON.parse(JSON.stringify(p))).placements,p.placements);});
test('Malformed imports fail without accepting bad IDs or dimensions',()=>{const p=C.blankPlan();p.items=[box()];p.items[0].l=-1;assert.throws(()=>C.assertPlan(p));p.items[0].l=1000;p.items.push({...p.items[0]});assert.throws(()=>C.assertPlan(p));});
test('Equipment changes update dimensions and retain fitting cargo without losing packages',()=>{
 const p=C.blankPlan(),c=p.containers[0],other=C.newContainer('40hc',2);p.containers.push(other);
 const a=box(),b=box(),d=box();p.items=[a,b,d];p.placements=[at(a,c),at(b,c,20,0,8000),at(d,other)];
 const kept=structuredClone(p.placements[0]),elsewhere=structuredClone(p.placements[2]);
 const removed=C.updateContainer(p,c.id,{...C.PRESETS['20gp'],preset:'20gp'});
 assert.equal(c.length,5898);assert.equal(c.height,2393);assert.equal(c.doorHeight,2280);assert.equal(c.payload,28200);
 assert.deepEqual(removed,[b.id]);assert.equal(p.items.length,3);assert.deepEqual(p.placements,[kept,elsewhere]);assert.equal(C.validateLayout(p).valid,true);
 for(const preset of ['40gp','40hc','45hc','20gp']){C.updateContainer(p,c.id,{...C.PRESETS[preset],preset});assert.equal(c.length,C.PRESETS[preset].length);assert.equal(c.height,C.PRESETS[preset].height);}
 assert.equal(C.assertPlan(JSON.parse(JSON.stringify(p))).containers[0].length,5898);
});
test('A lower container unplaces an unsupported stack and payload changes remain valid',()=>{
 const p=C.blankPlan(),c=p.containers[0],a=box({h:2350,stackable:true,maxTopLoad:200}),b=box({h:200,floorOnly:false});
 p.items=[a,b];p.placements=[at(a,c),at(b,c,20,2350)];assert.equal(C.validateLayout(p).valid,true);
 assert.equal(C.updateContainer(p,c.id,{...C.PRESETS['20gp'],preset:'20gp'}).length,2);assert.equal(p.items.length,2);assert.equal(p.placements.length,0);
 p.items=[box(),box()];C.placeOne(p,p.items[0].id,c.id);C.placeOne(p,p.items[1].id,c.id);
 C.updateContainer(p,c.id,{payload:100});assert.equal(C.validateLayout(p).valid,true);assert.equal(C.metrics(p,c.id).known,100);
});
test('Truck presets drive the model and survive custom sizing, packing and saved reload',()=>{
 for(const [preset,v] of Object.entries(C.TRUCK_PRESETS)){
  const p=C.blankPlan(),c=C.newContainer(preset);p.containers=[c];
  assert.equal(C.asVehicle(c).tur,v.type);assert.equal(c.wallGap,0);assert.equal(c.rearReserve,0);
  p.items=[box({l:1500,w:800,h:1800,weight:296.42487500000004})];
  C.applyEngine(p,planla(C.engineInput(p,true)));assert.equal(p.placements.length,1);
  const loaded=C.assertPlan(JSON.parse(JSON.stringify(p)));assert.equal(C.asVehicle(loaded.containers[0]).tur,v.type);
  C.updateContainer(loaded,c.id,{preset:'custom',length:4000});
  assert.equal(C.asVehicle(C.assertPlan(loaded).containers[0]).tur,v.type);
  assert.equal(loaded.items[0].weight,296.42487500000004);
 }
});
console.log(passed.map(t=>'PASS '+t).join('\n'));console.log(passed.length+' WinMatch cargo integration checks passed.');
